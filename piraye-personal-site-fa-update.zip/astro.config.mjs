import { defineConfig } from 'astro/config';

export default defineConfig({
  output: 'static',
  site: 'https://piraye-personal-site.blueuserno76045.chatgpt.site',
  build: { format: 'directory' },
});
